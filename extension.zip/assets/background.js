console.log("Background script running");chrome.runtime.onMessage.addListener((e,r,n)=>{e.type==="GET_TITLE"&&n({title:"Placeholder Title"})});
